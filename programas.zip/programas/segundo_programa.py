'''
Escreva um programa em Python que solicite 
3 notas de avaliacoes, calcule e mostre 
a media aritmetica dessas avaliacoes
'''

nota1 = float(input("Digite a primeira nota: "))
nota2 = float(input("Digite a segunda nota: "))
nota3 = float(input("Digite a terceira nota: "))

media = (nota1 + nota2 + nota3) /3

print(f"A media aritmetica dessas avaliacoes é {media:.1f}")