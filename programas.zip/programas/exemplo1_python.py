# Criacao de variaveis no python    

# Criacao de uma variavel numerica inteira
numero_inteiro = 15

# Funcao de saida de dados python (print) 
print (numero_inteiro)

# Criacao de uma variavel numerica real (float)
nota_aluno = 8.7

# Mostrar o conteudo da variavel nota_aluno
print(nota_aluno)

# Mostrar o tipo de dado nota_aluno
print(type(nota_aluno))

# Mostrar msg de texto junto com variavel
print(f"A nota do aluno é {nota_aluno}")

