# Função para entrada de dados (input)

# Entrada de uma variavel texto
nome = input("Digite o seu nome: ")
print(f"o nome da pessoa é {nome}")

sobrenome = input("Digite seu sobrenome: ")

# Entrada de uma variavel numerica inteira
idade = int(input("Digite sua idade: "))
print(f"A idade da pessoa é {idade}")


# Entrada de uma variavel numerica real (float)
salario_func = float(input("Digite o salario do funcionario:"))
print(f"O salario do funcionario é {salario_func}")

print(f"O nome da pessoa é {nome} {sobrenome}, sua idade é {idade} anos e ele recebe R${salario_func}.")
